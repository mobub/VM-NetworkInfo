#!/bin/bash
cat /etc/resolv.conf #this file contains information about your DNS settings.

ss -l #shows current listening sockets

iptables -L #shows the current firewall settings
