#!/bin/bash
netstat -rn #shows your kernel routing table 
netstat -g #shows IPv4 and IPv6 information
netstat -tnl #shows listening connections
netstat -i #shows your network interfaces
